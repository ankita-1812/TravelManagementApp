export class Admin{
    adminId:number=0;
    adminName:string="";
    adminMail:string="";
    adminAddr:string="";
    adminContactNo:string="";

}