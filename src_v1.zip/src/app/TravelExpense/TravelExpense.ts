export class TravelExpense{
    travelExpenseId:number=0;
    travelExpenseDate:string="";
    travelExpenseStatus:string="";
    travelDetails:string="";
    travelCostExpense:string="";
}