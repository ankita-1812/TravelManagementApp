

export class Employee{
    empId:number=0;
    empName:string="";
    empMail:string="";
    empAddr:string="";
    empDept:string="";
    empContactNo:string="";
   
}