export class LoginType { 
  
    constructor(public userId:number, public userType:string) {
    }
} 